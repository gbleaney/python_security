print("Win!")
